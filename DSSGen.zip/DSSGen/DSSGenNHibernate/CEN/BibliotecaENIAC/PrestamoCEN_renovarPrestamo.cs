
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using DSSGenNHibernate.EN.BibliotecaENIAC;
using DSSGenNHibernate.CAD.BibliotecaENIAC;

namespace DSSGenNHibernate.CEN.BibliotecaENIAC
{
public partial class PrestamoCEN
{
public bool RenovarPrestamo (string p_oid)
{
        /*PROTECTED REGION ID(DSSGenNHibernate.CEN.BibliotecaENIAC_Prestamo_renovarPrestamo) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method RenovarPrestamo() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
