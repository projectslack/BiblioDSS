
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using DSSGenNHibernate.EN.BibliotecaENIAC;
using DSSGenNHibernate.CAD.BibliotecaENIAC;

namespace DSSGenNHibernate.CEN.BibliotecaENIAC
{
public partial class UsuarioCEN
{
public bool Logearse (string p_oid, string contrasenya)
{
        /*PROTECTED REGION ID(DSSGenNHibernate.CEN.BibliotecaENIAC_Usuario_logearse) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method Logearse() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
