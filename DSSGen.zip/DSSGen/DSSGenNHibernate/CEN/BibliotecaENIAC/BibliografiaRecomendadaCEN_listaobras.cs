
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using DSSGenNHibernate.EN.BibliotecaENIAC;
using DSSGenNHibernate.CAD.BibliotecaENIAC;

namespace DSSGenNHibernate.CEN.BibliotecaENIAC
{
public partial class BibliografiaRecomendadaCEN
{
public void Listaobras (int p_oid)
{
        /*PROTECTED REGION ID(DSSGenNHibernate.CEN.BibliotecaENIAC_BibliografiaRecomendada_listaobras) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method Listaobras() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
