
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using DSSGenNHibernate.EN.BibliotecaENIAC;
using DSSGenNHibernate.CAD.BibliotecaENIAC;

namespace DSSGenNHibernate.CEN.BibliotecaENIAC
{
public partial class ObraCEN
{
public void BuscaPorTematica (string tema)
{
        /*PROTECTED REGION ID(DSSGenNHibernate.CEN.BibliotecaENIAC_Obra_buscaPorTematica) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method BuscaPorTematica() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
